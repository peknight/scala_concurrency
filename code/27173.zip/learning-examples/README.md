Learning Concurrent Programming in Scala
========================================

This repository contains the complete examples for the book Learning Concurrent Programming in Scala, published by Packt.

[![Packt Concurrency](concurrency-scala-book.jpg)](https://www.packtpub.com/application-development/learning-concurrent-programming-scala)
